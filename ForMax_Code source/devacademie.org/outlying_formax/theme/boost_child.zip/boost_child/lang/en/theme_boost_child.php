<?php
$string['pluginname'] = 'Boost Child';
